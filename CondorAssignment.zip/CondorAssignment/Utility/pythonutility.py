import datetime


def get_current_month():
    mydate = datetime.datetime.now()
    currentmonth = mydate.strftime("%B")
    currentmonth = currentmonth + " " + "2023"
    return currentmonth


print(get_current_month())
