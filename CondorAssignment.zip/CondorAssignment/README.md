# Condor Flight Reservation Assignment(WebApplication Automation)

This repository contains tools and configuration files for testing and automation needs of Flightbooking projet.Test cases of Flight reservation Web client application are automated using Selenium+Python+Robotframework at public environment.

Tools/technologies used: Python, Selenium, robot framework,

# Pre-Requisits : 
- tools : Pycharm communityedition
- programming language: python and set up system Path configuration
- installation and configuration: Install pycharm and add intellibot plugin
- Run install_libraries.bat file, required libraries will be installed
	**(Pip install robotframework, Pip install robotframework-seleniumlibrary, Pip install robotframework-allurereport, allure-robotframework, robotframework-pythonlibcore)**   


## Test tags

Tests in the testsuites have tags. Tags allow to run only a set of tests
identified by a tag. Several tags can be specified when running robot in the
following way:

```bash
robot -i <tag_01> -i <tag_02> testsuite/
```	
	
## Running the tests	

check Configuration file (before starting execution)
	-Select Routes
	-Provide Application Url
	-Provide Browser Name
	
	
# How to run scrip from cmd line:
-Go to project directory and run below commands:
- python -m robot -i SmokeTest  --outputdir TestExecutionResults    .\Features\.\Features\FeatureFlightBookings.robot  (To run only smoketest tagged test cases)
- python -m  robot  --outputdir TestExecutionResults    .\Features\FeatureFlightBookings.robot  (To run all test cases)
- python -m  robot  --rerunfailed   .\TestExecutionResults\output.xml  --output  .\TestExecutionResults\rerun.xml   .\Features\FeatureFlightBookings.robot     (To run only Failed Test cases)              
              

## Post-processing Robot output files

The output files of Robot include tyipically three files:

All logs can be found under TestExecutionResults folder

- `report.html`: overview of the test execution results in HTML format
- `log.html`: details about the executed test cases in HTML format
- `output.xml`: all the test execution results in machine readable XML format

More information about these files [here](https://robotframework.org/robotframework/latest/RobotFrameworkUserGuide.html#output-file).

It is possible to use the tool `rebot`, included as part of the Robot Framework, to post-process the output file `output.xml`.

```bash
# To re-generate log and report from output.xml:
rebot [-d <output_folder>] output.xml

# To re-generate log and report (and optionally new output.xml) to include only certain tags:
rebot [-d <output_folder>] -i <tag1> -i <tag2> ... -i <tagN> [-o <new_output_xml>] output.xml

# To re-generate log and report (and optionally new output.xml) excluding certain tags:
rebot [-d <output_folder>] -e <tag1> -e <tag2> ... -e <tagN> [-o <new_output_xml>] output.xml

# To merge several test executions:
rebot [-d <output_folder>] --merge output1.xml output2.xml ... outputN.xml
```

More information about post-processing Robot output files [here](https://robotframework.org/robotframework/latest/RobotFrameworkUserGuide.html#post-processing-outputs)

## Built With

* [Python](www.python.org/) - The language used
* [Robot Framework](robotframework.org) - The testing framework