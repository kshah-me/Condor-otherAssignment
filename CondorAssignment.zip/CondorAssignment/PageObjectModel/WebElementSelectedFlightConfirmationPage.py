Element_Selectedflight_confirmationpage_title = "xpath://h2[@class='h1']"
Element_Selectedflight_confirmationpage_seatselection = "xpath://a[@class='btn btn--large']"
Element_Selectedflight_confirmationpage_withoutseatselection = "xpath://a[contains(@id, 'express_checkout_button')]"
