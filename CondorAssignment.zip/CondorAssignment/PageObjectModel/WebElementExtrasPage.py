Element_extraspage_continue_button = "xpath://a[contains(text(),'Continue')]"
Element_extraspage_title = "//div[@class='flightpath__heading']/h1"
Element_extraspage_bookmeal_button = "//*[contains(text(),'Book meal')]/parent::a"
Element_extraspage_bookmeal_popup_title = "MODAL_TITLE_MEAL"
Element_extraspage_bookmeal_applybutton_on_popup = "//a[contains(text(),'Apply')]"

Element_moreextraspage_bookrail_button =  "//a[@aria.label='Book Rail&Fly']"
Element_moreextraspage_bookrail_applybutton_on_popup = "//a[contains(text(),'Apply')]"
