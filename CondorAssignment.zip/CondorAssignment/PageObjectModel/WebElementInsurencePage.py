Element_insurancepage_continuewithoutinsurance_button = "xpath://a[@aria-label='I have my own insurance']"
Element_insurancepage_title = "//div[@class='-warm-grey h3']"
Element_insurancepage_addinsurance_button = "xpath://a[@aria-label='Add insurance']"
Element_insurancepage_addinsurance_details_button = "//a[@class='btn ng-star-inserted']"

Element_insurancepage_addinsurance_Insurancesummary_confirmradiobutton = "//div[contains(text(),'Click here to " \
                                                                         "confirm.')] "

Element_insurancepage_addinsurance_Insurancesummary_confirmDonebutton = "//a[contains(text(),' Done ')]"

Element_insurancepage_continuewithinsurance_button = "xpath://a[@aria-label='Continue with insurance']"