Element_seatselection_page_afterseatselectionskipandcontinue = "xpath://a[contains(text(),'Skip and continue')]"
Element_seatselection_page_continuewithoutseats = "xpath://a[contains(text(),'Continue without seats')]"
Element_seatselection_page_seatselection_count = "//table/tbody/tr/td"
Element_seatselection_page_continuetoinboundseats = "xpath://a[contains(text(),'Continue to inbound seats')]"

Element_seatselection_page_titleoutbound = "xpath://h2[contains(@class,'seat-full-page__title')]"
Element_seatselection_page_titleinbound = "xpath://h2[contains(@class,'seat-full-page__title')]"
Element_seatselection_page_confirmcontinue_oninbound = "xpath://a[contains(text(),'Confirm and continue')]"
Element_seatselection_page_confirmcontinue = "xpath://a[contains(text(),'Confirm and continue')]"
Element_seatselection_page_Continuewithoutreserved = "xpath://a[contains(text(),'Continue without reserved seats')]"

