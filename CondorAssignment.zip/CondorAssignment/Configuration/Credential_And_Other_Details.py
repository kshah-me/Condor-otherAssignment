Url = 'https://www.condor.com/de'
Browser = 'chrome'