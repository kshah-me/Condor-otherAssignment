package com.eurowing.assignment.automation.feature.flight_status;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PageObjectModel {
	
	
	@FindBy(xpath = ".//span[contains(text(),'Show flight status')]/parent::span/parent::button")
	private WebElement Button_Show_flight_status;
	

	@FindBy(xpath = ".//span[contains(text(),'Departure airport')]/parent::div/parent::button")
	private WebElement Button_Dep_airport_input;


	@FindBy(xpath = ".//span[contains(text(),'Destination airport')]/parent::div/parent::button")
	private WebElement Button_Arv_airport_input;
	
	
	@FindBy(xpath = ".//input[@aria-label='Departure airport']")
	private WebElement Inputbox_Dep_airport_input;


	@FindBy(xpath = ".//input[@aria-label='Destination airport']")
	private WebElement Inputbox_Arv_airport_input;
		
	
	@FindBy(xpath = ".//input[@value='2023-03-16']")
	private WebElement Inputbox_Dep_Date_input;
	
	
	
	
	
	
	
	
	
	
}
