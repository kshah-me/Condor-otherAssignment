package com.sogeti.assignment.utility;

import io.restassured.http.Headers;
import io.restassured.http.Header;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class HeadersForAllRequests {
	

	public static Headers headers;

	public static Headers GetAllHeaders() {

        
        Header h1 = new Header("Content-Type", "application/json");
        List<Header> headerlist = new ArrayList<Header>();
        headerlist.add(h1);
        headers = new Headers(headerlist);
        return headers;

    }

}
