package com.conddor.assignment.petcreationpayload;

import com.conddor.assignment.petcreationpojo.Category;
import com.conddor.assignment.petcreationpojo.Tag;
import com.conddor.assignment.petcreationpojo.Root;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper; 
import java.util.ArrayList;


public class Petcreatepostbody{
	
	
	public static String requestbody(int id, String category_name, String name, String photoUrls, String tags_name, String status) throws JsonProcessingException {
		
		Category cat = new Category();
		cat.setId(id);
		cat.setName(category_name);		
		
		Tag  tag = new Tag();
		tag.setId(id);
		tag.setName(tags_name);
		ArrayList<Tag> alltags = new ArrayList<Tag>(); 
		alltags.add(tag);
		
		ArrayList<String> photos = new ArrayList<String>(); 
		photos.add(photoUrls);
		
		Root root = new Root();
		root.setId(id);
		root.setName(name);
		root.setStatus(status);
		root.setCategory(cat);
		root.setTags(alltags);
		root.setPhotoUrls(photos);
		
		ObjectMapper objmap = new ObjectMapper();
		
		String json =objmap.writerWithDefaultPrettyPrinter().writeValueAsString(root);
		
		return json;
	}
	
}