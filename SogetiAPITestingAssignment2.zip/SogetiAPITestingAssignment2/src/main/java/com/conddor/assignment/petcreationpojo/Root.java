package com.conddor.assignment.petcreationpojo;

import java.util.ArrayList;

public class Root {

	private Category category;
	private String name;
	private ArrayList<String> photoUrls;
	private ArrayList<Tag> tags;
	private String status;
	private int id;

    
        public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public Category getCategory() {
			return category;
		}
		public void setCategory(Category category) {
			this.category = category;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public ArrayList<String> getPhotoUrls() {
			return photoUrls;
		}
		public void setPhotoUrls(ArrayList<String> photoUrls) {
			this.photoUrls = photoUrls;
		}
		public ArrayList<Tag> getTags() {
			return tags;
		}
		public void setTags(ArrayList<Tag> alltags) {
			this.tags = alltags;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		@Override
		public String toString() {
			return "Root [category=" + category + ", name=" + name + ", photoUrls=" + photoUrls + ", tags=" + tags
					+ ", status=" + status + ", id=" + id + "]";
		}
		
	
	
}
