package com.condor.assignment.utility;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;

import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excelutility {


	public Object[][] getExcelData(String fileName, String sheetname) throws IOException {
		Object[][] data = null;
        
            FileInputStream fis = new FileInputStream(fileName);
            XSSFWorkbook workbook = new XSSFWorkbook(fis);
            XSSFSheet sheet = workbook.getSheet(sheetname);
            int noOfRows = sheet.getLastRowNum() + 1;
            int noOfCols = sheet.getRow(0).getLastCellNum();
            System.out.println(noOfRows);
            System.out.println(noOfCols);
            Cell cell;
            data = new Object[noOfRows - 1][noOfCols];
            for (int i = 1; i < noOfRows; i++) {
                for (int j = 0; j < sheet.getRow(0).getLastCellNum(); j++) {
                    cell = sheet.getRow(i).getCell(j);
                    System.out.println(cell);
                    switch (cell.getCellType()) {
                    case STRING :
                    	data[i - 1][j] = cell.getStringCellValue();
                    	break;
                    case NUMERIC :
                    	data[i - 1][j] = (int)cell.getNumericCellValue();	
                    	break;
                    case BLANK :
                    	data[i - 1][j] = "";	
                    	break;
					case BOOLEAN:
						break;
					case ERROR:
						break;
					case FORMULA:
						break;
					case _NONE:
						break;
					default:
						break;	
                    }
                }
            }
        return data;
    }


//	public static void main(String args[]) {
//		
//		Excelutility ex = new Excelutility();
//		try {
//			System.out.println(ex.getExcelData(System.getProperty("user.dir" )+ "/TestData.xlsx", "PostMethod"));
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			System.out.println("exception occur");
//		}
//	}
	
}


