package com.condor.assignment.petoperation;

import java.io.IOException;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.conddor.assignment.petcreationpayload.Petcreatepostbody;
import com.conddor.assignment.petcreationpojo.Root;
import com.condor.assignment.utility.Excelutility;
import com.condor.assignment.utility.HeadersForAllRequests;
import com.condor.assignment.utility.StatusCodeContentTypeValidation;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.specification.RequestSpecification;

public class PetAddUpdateGetDelete{

	RequestSpecification httprequest;
	Response response;
	int petId;
	String petName;
	
	@BeforeMethod
	public void setupMethod() throws IOException {
		RestAssured.baseURI = "https://petstore.swagger.io";
		RestAssured.useRelaxedHTTPSValidation();
		httprequest = RestAssured.given();
		
	}
	
	@DataProvider(name = "excelDataPostMethod")
    public Object[][] excelDataProviderPostMethod() throws IOException {
		Excelutility exceldata = new Excelutility();		
		Object[][] arrObj = exceldata.getExcelData(System.getProperty("user.dir" )+ "/TestData.xlsx" , "PostMethod");
        return arrObj;
}
	
	@DataProvider(name = "excelDataGetMethod")
    public Object[][] excelDataProviderGetMethod() throws IOException {
		Excelutility exceldata = new Excelutility();		
		Object[][] arrObj = exceldata.getExcelData(System.getProperty("user.dir" )+ "/TestData.xlsx", "GetMethod");        
		return arrObj;
}

	@DataProvider(name = "excelDataPutMethod")
    public Object[][] excelDataProviderPutMethod() throws IOException {
		Excelutility exceldata = new Excelutility();		
		Object[][] arrObj = exceldata.getExcelData(System.getProperty("user.dir" )+ "/TestData.xlsx", "PutMethod");
        return arrObj;
}
	
	
    
	
	@Test(dataProvider = "excelDataGetMethod", priority = 2)
	public void getPetDetailsById(int id, String category_name, String name) throws JsonMappingException, JsonProcessingException{
		
		httprequest.pathParam("petId", id);
		response = httprequest.request(Method.GET,"/v2/pet/{petId}");
		StatusCodeContentTypeValidation.passedStatusCodeValidation(response.getStatusCode());
		StatusCodeContentTypeValidation.contentTypeValidation(response.header("Content-Type"));
		ObjectMapper objmap = new ObjectMapper();
		Root root = objmap.readValue(response.getBody().asString(), Root.class);
		Assert.assertEquals(root.getId(), id);
		Assert.assertEquals(root.getCategory().getName(), category_name);
		Assert.assertEquals(root.getName(), name);
		
	}
	
	
	@Test(dataProvider = "excelDataPostMethod" , priority = 1)
	public void addNewPetDetails(int id, String category_name,	String name, String photoUrls, String tags_name, String status) throws JsonMappingException, JsonProcessingException{
		

		httprequest.header("Content-Type", "application/json");
		httprequest.body(Petcreatepostbody.requestbody(id, category_name, name, photoUrls, tags_name, status));
		response = httprequest.post("/v2/pet");
		StatusCodeContentTypeValidation.passedStatusCodeValidation(response.getStatusCode());
		StatusCodeContentTypeValidation.contentTypeValidation(response.header("Content-Type"));
		
		ObjectMapper objmap = new ObjectMapper();
		Root root = objmap.readValue(response.getBody().asString(), Root.class);
		Assert.assertEquals(root.getId(), id);
		Assert.assertEquals(root.getCategory().getName(), category_name);
		
	}
	
	
	@Test(dataProvider = "excelDataPutMethod" , priority = 3)
	public void updateExistingPetDetails(int id, String category_name,	String name, String photoUrls, String tags_name, String status) throws JsonMappingException, JsonProcessingException{
		
		
		httprequest.header("Content-Type", "application/json");
		httprequest.body(Petcreatepostbody.requestbody(id, category_name, name, photoUrls, tags_name, status));
		response = httprequest.put("/v2/pet");
		StatusCodeContentTypeValidation.passedStatusCodeValidation(response.getStatusCode());
		StatusCodeContentTypeValidation.contentTypeValidation(response.header("Content-Type"));
		
		ObjectMapper objmap = new ObjectMapper();
		Root root = objmap.readValue(response.getBody().asString(), Root.class);
		petId =root.getId();
		petName =root.getName();
		
	}
	

	@Test(dependsOnMethods = { "updateExistingPetDetails" })
	public void getPetDetailsById() throws JsonMappingException, JsonProcessingException{
		
		httprequest.pathParam("petId", petId);
		response = httprequest.request(Method.GET,"/v2/pet/{petId}");
		StatusCodeContentTypeValidation.passedStatusCodeValidation(response.getStatusCode());
		StatusCodeContentTypeValidation.contentTypeValidation(response.header("Content-Type"));
		ObjectMapper objmap = new ObjectMapper();
		Root root = objmap.readValue(response.getBody().asString(), Root.class);
		Assert.assertEquals(root.getName(), petName);
		
	}
  
  
	@Test(priority = 4)
	public void deletePetDetailsById() throws JsonMappingException, JsonProcessingException{
		
		httprequest.pathParam("petId", petId);
		response = httprequest.delete("/v2/pet/{petId}");
		StatusCodeContentTypeValidation.passedStatusCodeValidation(response.getStatusCode());
		StatusCodeContentTypeValidation.contentTypeValidation(response.header("Content-Type"));
		
	}
	
	
	@Test(dependsOnMethods = { "deletePetDetailsById" })
	public void getErrorPetDetailsNotFoundById() throws JsonMappingException, JsonProcessingException{
		
		httprequest.pathParam("petId", petId);
		response = httprequest.request(Method.GET,"/v2/pet/{petId}");
		StatusCodeContentTypeValidation.failedStatusCodeValidation(response.getStatusCode());
		StatusCodeContentTypeValidation.contentTypeValidation(response.header("Content-Type"));
		
		JsonPath jp = response.jsonPath();
		Assert.assertEquals(jp.get("message"), "Pet not found");  
	}
	
	
}


