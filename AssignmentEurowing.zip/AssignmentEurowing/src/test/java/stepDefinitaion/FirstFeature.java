package stepDefinitaion;

import org.testng.annotations.Test;

public class FirstFeature {

	@Test
	public void testjit() {
		System.out.println("Hello");
	}
}
