Url = "https://www.sogeti.com/"
Browser_name ="Chrome"

